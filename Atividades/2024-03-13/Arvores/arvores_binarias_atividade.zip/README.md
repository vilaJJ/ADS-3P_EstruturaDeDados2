# Atividade Avaliativa - Árvore Binária de Busca

1. Dados os valores {15, 10, 20, 5, 12, 18, 25, 3, 7, 11, 14, 17, 22, 2, 6, 9, 13, 16, 19, 24, 27, 1, 4, 8, 23, 26, 29, 30, 31, 32}, faça o que se pede:

    a. Crie um método que apresente a altura de uma árvore binária;

    b. Crie um método que apresente a altura de determinado nó de uma árvore binária;

    c. Crie um método que apresente os nós folha de uma árvore binária;

    d. Crie um método que apresente os nós internos de uma árvore binária;

    e. Crie um método que apresente somente os valores ímpares e menores de 23 em ordem;

    f. Crie um método que apresente somente os valores pares maiores que 14 em pós-ordem.

---

Data: 13 de março de 2024 (2024-03-13)