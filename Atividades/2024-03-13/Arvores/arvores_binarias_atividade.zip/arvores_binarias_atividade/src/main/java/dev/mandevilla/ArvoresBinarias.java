package dev.mandevilla;

import dev.mandevilla.Exercicio.ArvoreBinariaExercicio;

public class ArvoresBinarias {
    public static void main(String[] args) {
        System.out.println("Atividade avaliativa - Árvores binárias de busca");
        ArvoreBinariaExercicio.executar();
    }
}